const el = (id) => document.getElementById(id);
const featureSel = el("feature");
const fileInput = el("file");
const paramsInput = el("params");
const statusBox = el("status");
const bar = el("bar");
const results = el("results");
const preview = el("preview");
const dropzone = document.getElementById("dropzone");
const toastEl = document.getElementById("toast");

// --- Reference data for features ---
const REF_DATA = {
  enhance: {
    img: "./assets/enhance.svg",
    title: "智能修图增强",
    desc: "自动提亮、降噪与轻度美化，保持自然不过度。",
  },
  figurine: {
    img: "./assets/figurine2.svg",
    title: "插画转手办",
    desc: "将插画主体转为 3D 手办风格，突出造型与质感。",
  },
  era_style: {
    img: "./assets/era_style2.svg",
    title: "时代风格转换",
    desc: "一键迁移到特定年代风格，保留人物主体特征。",
  },
  hairstyle_grid: {
    img: "./assets/hairstyle.svg",
    title: "发型九宫格",
    desc: "尝试多种发型并一次性对比，选出更适合的造型。",
  },
  old_photo_restore: {
    img: "./assets/old_photo.svg",
    title: "老照片修复上色",
    desc: "修复划痕、降噪并自然上色，保留时代质感。",
  },
  id_photo: {
    img: "./assets/id_photo.svg",
    title: "证件照制作",
    desc: "规范背景与构图，输出标准证件照尺寸。",
  },
};

function updateRef(val){
  const d = REF_DATA[val] || REF_DATA.enhance;
  const img = document.getElementById("ref-img");
  const t = document.getElementById("ref-title");
  const s = document.getElementById("ref-desc");
  if (img) img.src = d.img;
  if (t) t.textContent = d.title;
  if (s) s.textContent = d.desc;
}

// --- Feature chips ---
const chipsWrap = document.getElementById("feature-chips");
if (chipsWrap) {
  chipsWrap.addEventListener("click", (e) => {
    const btn = e.target.closest(".chip");
    if (!btn) return;
    const val = btn.getAttribute("data-value");
    document.querySelectorAll("#feature-chips .chip").forEach((c) => c.classList.remove("chip-active"));
    btn.classList.add("chip-active");
    if (featureSel) featureSel.value = val;
    updateRef(val);
  });
}

// --- File select / preview ---
fileInput.addEventListener("change", () => updatePreview());
function updatePreview(){
  const f = fileInput.files?.[0];
  if (!f) return (preview.innerHTML = "");
  const url = URL.createObjectURL(f);
  preview.innerHTML = `<img src="${url}" alt="preview"/>`;
}

// --- Drag & Drop ---
if (dropzone) {
  ["dragenter","dragover"].forEach(ev => dropzone.addEventListener(ev, (e) => {
    e.preventDefault();
    dropzone.classList.add("dragover");
  }));
  ;["dragleave","drop"].forEach(ev => dropzone.addEventListener(ev, (e) => {
    e.preventDefault();
    dropzone.classList.remove("dragover");
  }));
  dropzone.addEventListener("drop", (e) => {
    const dt = e.dataTransfer;
    if (!dt || !dt.files || !dt.files[0]) return;
    const f = dt.files[0];
    try {
      const d = new DataTransfer();
      d.items.add(f);
      fileInput.files = d.files;
    } catch (_) {}
    updatePreview();
  });
}

// --- Submit ---
el("submit").addEventListener("click", async () => {
  const f = fileInput.files?.[0];
  if (!f) return toast("请先选择图片");

  let params = {};
  try { params = paramsInput.value ? JSON.parse(paramsInput.value) : {}; } catch (e) { return toast("参数必须是 JSON"); }

  const form = new FormData();
  form.append("type", featureSel.value);
  form.append("params", JSON.stringify(params));
  form.append("file", f);

  setProgress(3, "创建任务中...");
  const btn = el("submit");
  btn.disabled = true; btn.classList.add("opacity-70"); btn.textContent = "处理中...";
  try {
    const r = await fetch("/api/jobs", { method: "POST", body: form });
    if (!r.ok) throw new Error("创建任务失败");
    const { job_id } = await r.json();
    poll(job_id);
  } catch (err) {
    setProgress(0, "");
    toast(err.message || "网络错误");
  } finally {
    btn.disabled = false; btn.classList.remove("opacity-70"); btn.textContent = "开始处理";
  }
});

async function poll(jobId){
  const poller = setInterval(async () => {
    try {
      const r = await fetch(`/api/jobs/${jobId}`);
      if (!r.ok) throw new Error("查询失败");
      const s = await r.json();
      setProgress(s.progress ?? 0, s.status);
      if (s.status === "finished") {
        clearInterval(poller);
        renderResults(s.results || []);
        toast("已完成");
      }
      if (s.status === "failed") {
        clearInterval(poller);
        statusBox.textContent = `失败：${s.error || "未知错误"}`;
        toast("处理失败");
      }
    } catch (e) {
      clearInterval(poller);
      setProgress(0, "");
      toast("查询失败");
    }
  }, 1000);
}

function setProgress(p, text){
  bar.style.width = `${Math.min(100, Math.max(0, p))}%`;
  statusBox.textContent = text;
}

function renderResults(urls){
  results.innerHTML = urls.map(u => `
    <figure class="space-y-2">
      <img src="${u}" class="w-full rounded border border-slate-200"/>
      <div class="text-right">
        <a href="${u}" download class="text-sm text-blue-600 hover:underline">下载</a>
      </div>
    </figure>
  `).join("");
}

function toast(text){
  if (!toastEl) return alert(text);
  toastEl.textContent = text;
  toastEl.classList.remove("hidden");
  toastEl.classList.add("show");
  setTimeout(() => toastEl.classList.add("hide"), 10);
  setTimeout(() => { toastEl.classList.add("hidden"); toastEl.classList.remove("show","hide"); }, 2000);
}

// init ref on load
updateRef(featureSel?.value || "enhance");
